## 1.0.0-dev.1

- Initial version, created by D.I.E.N

## 1.0.1-dev.1

- Added debugging statements

## 1.0.2-dev.1

- Minor Fixes

## 1.0.3-dev.1

- Minor Fixes

## 1.0.4-dev.1

- Minor Fixes

## 1.0.5-dev.1

- Minor Fixes

## 1.0.6-dev.1

- Touchy callback now accepts args

## 1.0.7-dev.1

- Touchy callback now accepts args fixed

## 1.0.8-dev.1

- Touchy callback now accepts args minor fixes

## 1.0.10-dev.1

- Minor fixes

## 1.0.11-dev.1

- Minor fixes

## 1.0.12-dev.1

- Minor fixes

## 1.0.13-dev.1

- Minor fixes

## 1.0.14-dev.1

- Removed touch event defaults to fix issues of firing click on chrome too

## 1.0.15-dev.1

- Updated Readme

## 1.0.16-dev.1

- Minor fixes
