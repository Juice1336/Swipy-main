import 'package:onycha/onycha.dart';

void main() {
  print('Look at readme to see example');
}
